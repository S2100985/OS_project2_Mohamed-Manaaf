# mm2-fayaaz-OS_groupProject2_S2100985

## Name
pintOS System calls

##Date Created
24th of April 2023

## Description
This project focucses on implementing system calls, which was doen through modifying the userprog/ syscall.c file, a switch case is made to assign a specific function to the system call so once it has been called that function gets performed.
## Installation
For this program ubuntu 16 .iso file was downloaded and run on the oracle VM virtual box, once ubuntu was installed the binutils version 2.25.1 and gcc 5.3.0 were installed, then the pintOS folder was cloned from uwe gitlab.

## Support
A lab report handed out by UWE was used. 

## Project status
The development for this project has stopped for the forseeable future.

## Additionally
There are screenshots of the outcomes recieved by altering the syscall.c file in this repository.
